# Adatron SVM with polynomial kernel
# placed in the public domain by Stavros Korokithakis
# Performance-tuned for Psyco (and adapted for translation to D2), and then
# adapted for ShedSkin by leonardo maffi, v1.0, Jun 27 2010.


from math import exp

class Kind(object):
    CYTOSOLIC = 0
    EXTRACELLULAR = 1
    NUCLEAR = 2
    MITOCHONDRIAL = 3
    BLIND = 4


D = 5.0
LENGTH = 50
AMINOACIDS = "ACDEFGHIKLMNPQRSTVWY"

class Protein(object):
    __slots__ = "name mass isoelectricPoint size sequence type localComposition globalComposition".split()
    def __init__(self, name, mass, isoelectricPoint, size, sequence, type):
        self.name = name
        self.mass = mass
        self.isoelectricPoint = isoelectricPoint
        self.size = size
        self.sequence = sequence
        self.type = type
        self.extractComposition()
        self.localComposition = {}
        self.globalComposition = {}

    def extractComposition(self):
        d1 = {}
        d2 = {}

        for aminoacid in AMINOACIDS:
            d1[aminoacid] = 0.0
            d2[aminoacid] = 0.0

        for counter in xrange(LENGTH):
            d1[self.sequence[counter]] += 1.0 / LENGTH
        self.localComposition = d1

        for aminoacid in self.sequence:
            d2[aminoacid] += 1.0 / len(self.sequence)
        self.globalComposition = d2

    def createVector(self):
        # self method probably has a bug because vector gets
        # filled with two different types
        vector = []
        lastval = 0.0
        for key, value in sorted(self.localComposition.items()):
            vector.append(value)
            lastval = value
        for key in self.globalComposition:
            vector.append(lastval)
        return vector


def loadFile(filename, type, proteins):
    protFile = open(filename)
    for line in protFile:
        if line.startswith("name"):
            continue
        name, mass, isoelectricPoint, size, sequence = line.strip().split("\t")
        protein = Protein(name, mass, isoelectricPoint, size, sequence, type)
        proteins.append(protein)
    protFile.close()


def createTables(proteins):
    """Create the feature and label tables."""
    featureTable = []
    labelTable = []

    for protein in proteins:
        featureTable.append(protein.createVector())

    for protein in proteins:
        if (protein.type == Kind.BLIND):
            continue
        labels = [-1, -1, -1, -1]

        # Invert the sign of the label our protein belongs to.
        labels[protein.type] *= -1
        labelTable.append(labels)

    return featureTable, labelTable


def createKernelTable(featureTable):
    len_featureTable = len(featureTable)
    kernelTable = [[0.0] * len_featureTable for _ in xrange(len_featureTable)]
    for r in xrange(len_featureTable):
        row = featureTable[r]
        kernelTable_r = kernelTable[r]
        for c in xrange(len_featureTable):
            candidate = featureTable[c]
            difference = 0.0
            for counter in xrange(len(row)):
                difference += (row[counter] - candidate[counter]) ** 2
            kernelTable_r[c] = exp(-D * difference)
    return kernelTable

def trainAdatron(kernelTable, labelTable, h, c, max_steps):
    len_kernelTable = len(kernelTable)
    TOLERANCE = 0.5
    alphas = [[0.0] * len_kernelTable for _ in xrange(len(labelTable[0]))]
    assert len(alphas) == len(labelTable[0])
    assert len(alphas[0]) == len_kernelTable
    betas = [[0.0] * len_kernelTable for _ in xrange(len(labelTable[0]))]
    assert len(betas) == len(labelTable[0])
    assert len(betas[0]) == len_kernelTable
    bias = [0.0] * len(labelTable[0])
    labelAlphas = [0.0] * len_kernelTable
    maxDifferences = [(0.0, 0)] * len(labelTable[0])

    for iteration in xrange(10 * len_kernelTable):
        print "Starting iteration %s..." % iteration
        if iteration == max_steps: # XXX shedskin test
            return alphas, bias

        for klass in xrange(len(labelTable[0])): # 4 loops
            maxDifferences[klass] = (0.0, 0)
            for elem in xrange(len_kernelTable):
                labelAlphas[elem] = labelTable[elem][klass] * alphas[klass][elem]

            # self section is the slowest part of the program
            for colCounter in xrange(len_kernelTable):
                prediction = 0.0
                # prediction = dot_product(kernelTable[colCounter], labelAlphas)
                kernelTable_colCounter = kernelTable[colCounter]
                for rowCounter in xrange(len_kernelTable): # most critical loop of the program
                    prediction += kernelTable_colCounter[rowCounter] * labelAlphas[rowCounter]
                g = 1.0 - ((prediction + bias[klass]) * labelTable[colCounter][klass])
                betas[klass][colCounter] = min(max((alphas[klass][colCounter] + h * g), 0.0), c)
                difference = abs(alphas[klass][colCounter] - betas[klass][colCounter])
                if (difference > maxDifferences[klass][0]):
                    maxDifferences[klass] = (difference, colCounter)

            allTrue = True
            for maxDifference in maxDifferences:
                if (maxDifference[0] >= TOLERANCE):
                    allTrue = False
                    break

            if allTrue:
                return alphas, bias
            else:
                alphas[klass][maxDifferences[klass][1]] = betas[klass][maxDifferences[klass][1]]
                elementSum = 0.0
                for elementCounter in xrange(len_kernelTable):
                    elementSum += labelTable[elementCounter][klass] * alphas[klass][elementCounter] / 4
                bias[klass] = bias[klass] + elementSum


def calculateError(alphas, bias, kernelTable, labelTable):
    len_kernelTable = len(kernelTable)
    prediction = 0.0
    predictions = [[0.0] * len_kernelTable for _ in xrange(len(labelTable[0]))]
    assert len(predictions) == len(labelTable[0])
    assert len(predictions[0]) == len_kernelTable

    for klass in xrange(len(labelTable[0])):
        alphas_klass = alphas[klass]
        for colCounter in xrange(len_kernelTable):
            kernelTable_colCounter = kernelTable[colCounter]
            for rowCounter in xrange(len_kernelTable):
                prediction += kernelTable_colCounter[rowCounter] * \
                              labelTable[rowCounter][klass] * alphas_klass[rowCounter]
            predictions[klass][colCounter] = prediction + bias[klass]

    for colCounter in xrange(len(kernelTable)):
        currentPredictions = []
        error = 0
        for rowCounter in xrange(len(labelTable[0])):
            currentPredictions.append(predictions[rowCounter][colCounter])

        predictedClass = currentPredictions.index(max(currentPredictions))

        if (labelTable[colCounter][predictedClass] < 0):
            error += 1

        return 1.0 * error / len(kernelTable)


def main():
    proteins = []
    for filename, type in [("c", Kind.CYTOSOLIC), ("e", Kind.EXTRACELLULAR),
                           ("n", Kind.NUCLEAR), ("m", Kind.MITOCHONDRIAL)]: #, ("b", Kind.BLIND)]:
        loadFile(filename + ".txt", type, proteins)
    print "Creating feature tables..."
    featureTable, labelTable = createTables(proteins)
    print "Creating kernel table..."
    kernelTable = createKernelTable(featureTable)
    print "Training SVM..."
    alphas, bias = trainAdatron(kernelTable, labelTable, 1.0, 3.0, max_steps=20)
    err = calculateError(alphas, bias, kernelTable, labelTable)
    print err


if __name__ == "__main__":
    main()