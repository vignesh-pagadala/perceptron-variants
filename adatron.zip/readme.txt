Adatron algorithm in Python, Psyco, D2, D1

By leonardo maffi, V.1.1, Jul 3 2010


This is a program taken from the test suite of ShedSkin:
http://shedskin.googlecode.com/svn/trunk/examples/adatron.py

Original comment to the code:
Adatron SVM with polynomial kernel, placed in the public domain by Stavros Korokithakis.


Sorted versions of the program:
- adatron_orig.py: original Python program from ShedSkin examples. This compiles with ShedSkin.
- adatron_opt.py: Python program optimized and adapted for a translation to D v2 language.
- adatron_d.d: translation to D v2 of adatron_opt.py.
- adatron_ugly_ldc.d: ugly version of the D program adapted to D v1, for Phobos and Tango.
- adatron_opt_ss.py: adatron_opt.py modified a little so it can be compiled with ShedSkin.
- dot_product_double.d, dot_product_float.d: experimental asm implementations of dot product of two dynamic arrays of doubles and floats. It's incomplete and it's efficient only on large arrays.
- adatron_d_asm.d: version of adatron_d.d with two routines in asm, for dmd2. It's faster than adatron_d.d. One of the two routines is useless for ldc.

The files c.txt e.txt m.txt n.txt are test data used by the programs.

----------------------

Timings adatron, 20 loops, output redirected to file, seconds, best of 3, seconds, on Ubuntu:
  D LDC+LTO:           1.42 (with link-time optimization)
  D LDC:               1.43
  ShedSkin opt -O3:    1.78
  ShedSkin orig -O3:   2.17
  Psyco opt:          16.24
  Python orig:       139.

Timings adatron, 20 loops, output redirected to file, seconds, best of 3, seconds, on Vista:
  D dmd:               1.26
  Psyco opt:           7.5

ShedSkin code is compiled with SS V.0.5:
-O3 -msse2 -fomit-frame-pointer

D dmd code compiled with v2.047:
-O -release -inline

D ldc code compiled with ldc based on DMD v1.057 and llvm 2.6 (Tue Mar 23 22:38:09 2010):
-O5 -release -inline

Psyco on Windows Vista and Ubuntu:
Psyco 1.6.0 final 0

Ubuntu running on VirtualBox on Vista.

CPU Intel Celeron 2.13 GHz.

-------------------------

The slowest part of the program is the dot product. In D it can be replaced by an ASM routine.

But I have found another spot where D compiled with DMD gives slower performance than Psyco, the createKernelTable(). Here I have extracted just its inner loop to see how DMD compiles it:


// D code
double foo(double[] arr1, double[] arr2) {
    double diff = 0.0;
    for (int i; i < arr1.length; i++) {
        double aux = arr1[i] - arr2[i];
        diff += aux * aux;
    }
    return diff;
}
void main() {}


DMD:
L38:    fld qword ptr [EDX*8][ECX]
        fsub    qword ptr [EDX*8][EBX]
        inc EDX
        cmp EDX,058h[ESP]
        fstp    qword ptr 014h[ESP]
        fld qword ptr 014h[ESP]
        fmul    ST,ST(0)
        fadd    qword ptr 4[ESP]
        fstp    qword ptr 4[ESP]
        jb  L38


LDC:
.LBB13_5:
    movsd   (%edi,%ecx,8), %xmm1
    subsd   (%eax,%ecx,8), %xmm1
    incl    %ecx
    cmpl    %esi, %ecx
    mulsd   %xmm1, %xmm1
    addsd   %xmm1, %xmm0
    jne .LBB13_5

--------------------------

Then I have translated it to C to see how GCC compiles it:


// C code
double foo(double* arr1, double* arr2, int len) {
    double diff = 0.0;
    int i;
    for (i = 0; i < len; i++) {
        double aux = arr1[i] - arr2[i];
        diff += aux * aux;
    }

    return diff;
}

gcc 4.5 (C code, 64 bit):
L3:
    movsd   (%rcx,%rax), %xmm1
    subsd   (%rdx,%rax), %xmm1
    addq    $8, %rax
    cmpq    %r8, %rax
    mulsd   %xmm1, %xmm1
    addsd   %xmm1, %xmm0
    jne L3


gcc 4.5 (C code, 32 bit):
L3:
    fldl    (%ecx,%eax,8)
    fsubl   (%ebx,%eax,8)
    addl    $1, %eax
    cmpl    %edx, %eax
    fmul    %st(0), %st
    faddp   %st, %st(1)
    jne L3


gcc 4.5 (C code, 32 bit, more opt):
L3:
    fldl    (%ecx,%eax,8)
    fsubl   (%ebx,%eax,8)
    incl    %eax
    fmul    %st(0), %st
    cmpl    %edx, %eax
    faddp   %st, %st(1)
    jne L3


gcc 4.5 (C code, 32 bit, forced SSE):
L3:
    movsd   (%ecx,%eax,8), %xmm0
    subsd   (%ebx,%eax,8), %xmm0
    incl    %eax
    mulsd   %xmm0, %xmm0
    cmpl    %edx, %eax
    addsd   %xmm0, %xmm1
    jne L3

-----------------------------

I have unrolled the C code:

// C code, unrolled once
double foo(double* arr1, double* arr2, int len) {
    double diff1 = 0.0;
    double diff2 = 0.0;
    int i;
    for (i = 0; i < len; i += 2) {
        double aux1 = arr1[i] - arr2[i];
        diff1 += aux1 * aux1;
        double aux2 = arr1[i+1] - arr2[i+1];
        diff2 += aux2 * aux2;
    }

    return diff1 + diff2;
}


GCC 64 bit:
L3:
    movsd   (%rcx,%rax), %xmm1
    subsd   (%rdx,%rax), %xmm1
    mulsd   %xmm1, %xmm1
    addsd   %xmm1, %xmm2
    movsd   8(%rcx,%rax), %xmm1
    subsd   8(%rdx,%rax), %xmm1
    addq    $16, %rax
    mulsd   %xmm1, %xmm1
    cmpq    %r8, %rax
    addsd   %xmm1, %xmm0
    jne L3

-----------------------------

I have SIMD-fied the C code, note the usage of movapd that requires aligned pointers:

// C code
typedef double double2 __attribute__ (( vector_size(2*sizeof(double)) ));

#define uppper(_V) (((double*)&_V)[1])
#define lower(_V) (((double*)&_V)[0])

double foo(double2* arr1, double2* arr2, int len) {
    double2 diff = {0.0, 0.0};
    int i;
    for (i = 0; i < (len / 2); i++) {
        double2 aux1 = arr1[i] - arr2[i];
        diff += aux1 * aux1;
    }

    return uppper(diff) + lower(diff);
}


GCC 64 bit:
L3:
    movapd  (%rcx,%r8), %xmm0
    subpd   (%rdx,%r8), %xmm0
    addq    $16, %r8
    mulpd   %xmm0, %xmm0
    cmpq    %rax, %r8
    addpd   %xmm0, %xmm1
    jne L3


GCC 32 bit:
L3:
    movapd  (%ebx,%eax), %xmm0
    incl    %edx
    subpd   (%esi,%eax), %xmm0
    addl    $16, %eax
    mulpd   %xmm0, %xmm0
    cmpl    %ecx, %edx
    addpd   %xmm0, %xmm1
    jne L3

----------------------

I have SIMD-fied the C code and unrolled it once:

typedef double double2 __attribute__ (( vector_size(2*sizeof(double)) ));

#define uppper(_V) (((double*)&_V)[1])
#define lower(_V) (((double*)&_V)[0])

double foo(double2* arr1, double2* arr2, int len) {
    double2 diff1 = {0.0, 0.0};
    double2 diff2 = {0.0, 0.0};
    int i;
    for (i = 0; i < len; i += 2) {
        double2 aux1 = arr1[i] - arr2[i];
        diff1 += aux1 * aux1;
        double2 aux2 = arr1[i+1] - arr2[i+1];
        diff2 += aux2 * aux1;
    }

    diff1 += diff2;
    return uppper(diff1) + lower(diff1);
}


GCC 64 bit:
L3:
    movapd  (%rcx,%rax), %xmm1
    subpd   (%rdx,%rax), %xmm1
    movapd  %xmm1, %xmm0
    mulpd   %xmm1, %xmm0
    addpd   %xmm0, %xmm2
    movapd  16(%rcx,%rax), %xmm0
    subpd   16(%rdx,%rax), %xmm0
    addq    $32, %rax
    mulpd   %xmm1, %xmm0
    cmpq    %r8, %rax
    addpd   %xmm0, %xmm3
    jne L3


GCC 32 bit:
L3:
    movapd  (%ecx,%eax), %xmm1
    addl    $2, %edx
    subpd   (%ebx,%eax), %xmm1
    movapd  %xmm1, %xmm0
    mulpd   %xmm1, %xmm0
    addpd   %xmm0, %xmm2
    movapd  16(%ecx,%eax), %xmm0
    subpd   16(%ebx,%eax), %xmm0
    addl    $32, %eax
    mulpd   %xmm1, %xmm0
    cmpl    %edx, %esi
    addpd   %xmm0, %xmm3
    jg  L3

----------------------

